<?php


$botToken="8056151844:AAF6tuJW_m_Bsyzz6uOmKCK0yhZ0XrnPbIA";
$chatId="1598917262";  


?>